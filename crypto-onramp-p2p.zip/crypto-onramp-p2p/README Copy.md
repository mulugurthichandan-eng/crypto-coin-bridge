# 🚀 CRYPTO-COINBRIDGE // Full-Stack P2P & Fiat On-Ramp Platform

A full-stack crypto trading web application featuring an instant fiat-to-crypto on-ramp and a Peer-to-Peer (P2P) trading hub backed by an atomic Escrow State Engine, built with **React 18**, **Tailwind CSS**, and **Node.js v24 (Native SQLite + Native HTTP Server)**.

---

## 📱 Visual Design & Screen Overview

This platform implements the exact four-screen user flow specified in the project prompt and reference mockups:

1. **Screen 1: Landing & Quick Buy**
   - Branded navigation header `CRYPTO-COINBRIDGE` with `Get Started ∨` dropdown.
   - Hero header: *"Buy, Sell & Swap Crypto"* with subtext *"Instant fiat-to-crypto access in 75+ countries."*
   - Core swap card with segmented `Buy` / `Sell` toggle.
   - Quick crypto selection buttons: **BTC** (orange badge, active by default), **ETH**, **USDT**, and **Other** (modal for SOL, ADA, XRP).
   - Trust indicators: *"Lowest processing fee"* and *"Secure & instant transactions"*.
   - Prominent blue `Buy Now` CTA button that routes smoothly to Screen 2.

2. **Screen 2: Order Confirmation (With P2P Integration)**
   - Header with `<` back navigation to Quick Buy.
   - **Pay Input**: Default `70,000` with currency selector pill (🇮🇳 INR, USD, EUR, AED).
   - **You Get Output**: Dynamic calculation (`0.00905305 BTC`) calculated real-time using live rate `1 BTC = ₹77,05,586.30`.
   - **Payment Method Cards**:
     - *Option A*: UPI (`PhonePe, GPay, etc.`)
     - *Option B*: Highlighted **Peer-to-Peer (P2P)** with neon green glowing border, zero fees tag, and *"Buy directly from verified P2P Merchants"*.
   - Prominent blue `Proceed to P2P` CTA routing directly into the active P2P marketplace.

3. **Screen 3: P2P Merchant Onboarding (Role-based Feature)**
   - Trust badge illustration featuring a glowing shield with green checkmark and star sparkles.
   - Header: *"Apply to become a P2P Merchant & Earn by facilitating local buy and sell orders"*.
   - Inputs:
     - Merchant Trade Name input (e.g. `crypto_pro_desk`).
     - Security Deposit input (e.g. `500 USDT`).
     - Supported payment methods multi-select: **UPI** and **Bank Transfer**.
   - CTA: *"Submit Application & Create P2P Merchant Account"*.
   - Footnote: *"Normal users can buy and sell instantly without merchant registration"*.
   - Persistence: Automatically creates a verified merchant profile in the database and renders their listing in the P2P Hub feed.

4. **Screen 4: P2P Marketplace (The Active Hub)**
   - Segmented `Buy` / `Sell` filter tabs.
   - Filter pills for Crypto (`BTC`, `USDT`, `ETH`) and Fiat (`INR`, `USD`).
   - Dynamic Merchant Cards matching the reference design:
     - Crown icon / verified checkmark badge: `crypto_king (99% completion)`.
     - Visual green completion progress bar.
     - Price: `Price: ₹77,10,000`.
     - Transaction Limits: `Limits: ₹10,000 - ₹1,00,000`.
     - Active action button: green `Buy BTC` (or red `Sell BTC`).
     - Second card: `trade_fast (95% completion)`, `Price: ₹77,08,000`, `Limits: ₹5,000 - ₹50,000`.
   - Sticky bottom navigation bar with 4 tabs:
     - 🔄 **Buy/Sell**
     - ⇄ **P2P Trade** (active glowing blue pill)
     - 🏛️ **Merchant Hub**
     - 👤 **Profile**

---

## ⚡ Multi-View Presentation Modes

To give you the exact presentation experience of the reference mockup plus a full web app experience, a top switcher allows toggling between three display modes:

- 📱 **Interactive Phone**: An iPhone 15 Pro titanium simulator with dynamic island, status bar with live clock, and step-by-step navigation.
- 🖼️ **4-Screen Reference View**: All four mobile screens rendered side-by-side in real-time, exactly matching the reference presentation graphic!
- 💻 **Desktop View**: A widescreen fintech trading dashboard with orderbooks, conversion calculators, and merchant cards.

---

## 🔒 Escrow Engine & Anti-Scam Security Logic

Peer-to-Peer crypto transactions inherently carry fraud risks if fiat and crypto transfers are uncoordinated. This platform implements a 4-state atomic Escrow Engine:

```
[Buyer taps 'Buy BTC'] 
         │
         ▼
[1. ESCROW_LOCKED] ────► Seller's 0.00905305 BTC is immediately locked in Fiat_Escrow table.
         │                Seller cannot withdraw or cancel during active trade window.
         ▼
[2. FIAT PAYMENT]  ────► Buyer transfers ₹70,000 via UPI (PhonePe/GPay) to Seller's UPI ID.
         │
         ▼
[3. PAID_MARKED]   ────► Buyer taps "I Have Transferred INR (Mark as Paid)". 15-minute dispute timer starts.
         │
         ▼
[4. ESCROW RELEASE] ───► Seller verifies fiat deposit in their banking app & taps "Release".
                          Crypto is atomically transferred into Buyer's wallet ledger.
```

If the seller fails to release after verified receipt, the arbitrator steps in with proof of payment to force-release from the escrow smart vault.

---

## 💾 Database Schema (SQLite 3 via `node:sqlite`)

The backend initializes and manages 4 relational tables in `p2p_crypto.db`:

```sql
-- 1. USERS: User authentication & wallet balances
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE,
  name TEXT,
  role TEXT DEFAULT 'USER',               -- 'USER' | 'MERCHANT'
  fiat_balance REAL DEFAULT 150000.0,
  btc_balance REAL DEFAULT 0.045,
  eth_balance REAL DEFAULT 1.25,
  usdt_balance REAL DEFAULT 2500.0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. MERCHANTS: Verified merchant profiles & advertising ads
CREATE TABLE merchants (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  trade_name TEXT,
  security_deposit REAL,
  deposit_asset TEXT DEFAULT 'USDT',
  completion_rate REAL DEFAULT 99.0,
  total_trades INTEGER DEFAULT 142,
  supported_methods TEXT,                  -- JSON Array: ["UPI", "Bank Transfer"]
  min_limit REAL DEFAULT 10000.0,
  max_limit REAL DEFAULT 100000.0,
  price_inr REAL DEFAULT 7710000.0,
  price_usd REAL DEFAULT 92500.0,
  crypto_symbol TEXT DEFAULT 'BTC',
  fiat_symbol TEXT DEFAULT 'INR',
  trade_type TEXT DEFAULT 'BUY',
  is_verified INTEGER DEFAULT 1,
  status TEXT DEFAULT 'ACTIVE',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. P2P_ORDERS: Trade execution and transaction history
CREATE TABLE p2p_orders (
  id TEXT PRIMARY KEY,
  order_no TEXT UNIQUE,
  buyer_id TEXT,
  seller_id TEXT,
  merchant_id TEXT,
  crypto_symbol TEXT,
  fiat_symbol TEXT,
  crypto_amount REAL,
  fiat_amount REAL,
  unit_price REAL,
  payment_method TEXT,
  status TEXT DEFAULT 'PENDING',          -- 'ESCROW_LOCKED' | 'PAID_MARKED' | 'COMPLETED'
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. FIAT_ESCROW: Smart escrow lock ledger
CREATE TABLE fiat_escrow (
  id TEXT PRIMARY KEY,
  order_id TEXT UNIQUE,
  crypto_amount REAL,
  crypto_symbol TEXT,
  locked_from_user_id TEXT,
  status TEXT DEFAULT 'LOCKED',           -- 'LOCKED' | 'RELEASED_TO_BUYER' | 'DISPUTE_HOLD'
  lock_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  release_timestamp DATETIME,
  dispute_reason TEXT
);
```

---

## 🏗️ Feature-Sliced Design (FSD) Codebase Architecture

```
crypto-onramp-p2p/
├── server.js               # Node.js backend: REST endpoints, SQLite DB, Escrow state engine
├── p2p_crypto.db           # Persistent SQLite database file
├── package.json            # Project manifest
├── start.bat               # Windows 1-click batch launcher
├── run.ps1                 # PowerShell terminal launcher
├── README.md               # Complete architecture & design documentation
└── public/
    ├── index.html          # HTML5 entry with Tailwind CSS & React 18 CDN
    ├── app.jsx             # React SPA with 4 Screens, Quad-Phone mode, Escrow modals
    └── styles.css          # Fintech dark mode theme, titanium phone chassis, animations
```

---

## 🚀 How to Run

### Method 1: Double-Click
Double-click `start.bat` in this folder (`C:\Users\jagan\.gemini\antigravity\scratch\crypto-onramp-p2p`).
It will start the server and open **`http://localhost:3001`** in your default web browser automatically!

### Method 2: PowerShell
```powershell
cd C:\Users\jagan\.gemini\antigravity\scratch\crypto-onramp-p2p
.\run.ps1
```

### Method 3: Direct Node Execution
```powershell
& "C:\Users\jagan\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.js
```
Then navigate to **`http://localhost:3001`**.
