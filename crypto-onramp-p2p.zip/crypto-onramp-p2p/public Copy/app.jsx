/**
 * CRYPTO-COINBRIDGE // Modern Full-Stack Fintech Web Application
 * Built with React 18, Tailwind CSS, Lucide SVG Icons, and Node 24 SQLite Backend
 */

const { useState, useEffect, useMemo, useRef } = React;

// ----------------------------------------------------
// Custom SVG Icons
// ----------------------------------------------------
const Icons = {
  Btc: () => (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="16" fill="#F7931A" />
      <path d="M22.5 13.8c.3-2.1-1.3-3.2-3.5-3.9l.7-2.9-1.8-.4-.7 2.8c-.5-.1-.9-.2-1.4-.3l.7-2.8-1.8-.4-.7 2.9c-.4-.1-.8-.2-1.2-.3l-2.4-.6-.5 1.9s1.3.3 1.3.3c.7.2.8.7.8 1.1l-.8 3.2c0 .1.1.1.1.1l-.1 0-.9 3.5c-.1.2-.3.6-.8.4 0 0-1.3-.3-1.3-.3l-.9 2.1 2.3.6c.4.1.8.2 1.3.3l-.7 3 1.8.4.7-2.9c.5.1.9.2 1.4.3l-.7 2.9 1.8.4.7-2.9c3 .6 5.3.3 6.2-2.4.8-2.1 0-3.4-1.5-4.2 1.1-.3 1.9-1 2.1-2.5zm-3.8 5.4c-.6 2.3-4.4 1.1-5.7.7l1-4.1c1.2.3 5.3 1 4.7 3.4zm.5-5.6c-.5 2.1-3.7 1-4.7.7l.9-3.7c1.1.3 4.4.9 3.8 3z" fill="#FFF" />
    </svg>
  ),
  Eth: () => (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="16" fill="#627EEA" />
      <path d="M16 4l-.2.7v16.1l.2.2 7.5-4.4L16 4z" fill="#FFF" fillOpacity="0.6" />
      <path d="M16 4L8.5 16.6l7.5 4.4V4z" fill="#FFF" />
      <path d="M16 22.4l-.1.1v6.9l.1.4 7.5-10.4L16 22.4z" fill="#FFF" fillOpacity="0.6" />
      <path d="M16 29.8v-7.4L8.5 19.4 16 29.8z" fill="#FFF" />
      <path d="M16 21l7.5-4.4L16 12.8v8.2z" fill="#FFF" fillOpacity="0.2" />
      <path d="M8.5 16.6l7.5 4.4v-8.2L8.5 16.6z" fill="#FFF" fillOpacity="0.6" />
    </svg>
  ),
  Usdt: () => (
    <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="16" fill="#26A17B" />
      <path d="M17.9 16.7c-.1 0-.9 0-1.9 0-1 0-1.8 0-1.9 0-4.3-.2-7.5-1.1-7.5-2.2 0-1.1 3.2-2 7.5-2.2v3.4c.1 0 .9 0 1.9 0 1 0 1.8 0 1.9 0v-3.4c4.3.2 7.5 1.1 7.5 2.2 0 1.1-3.2 2-7.5 2.2zm0-4.9v-2.6h6.8V6.4H7.3v2.8h6.8v2.6c-4.9.2-8.6 1.3-8.6 2.7 0 1.3 3.7 2.4 8.6 2.7v7.6h3.8v-7.6c4.9-.2 8.6-1.3 8.6-2.7 0-1.3-3.7-2.5-8.6-2.7z" fill="#FFF" />
    </svg>
  ),
  Sol: () => (
    <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-purple-600 to-teal-400 flex items-center justify-center text-[10px] font-black text-white">
      S
    </div>
  ),
  IndiaFlag: () => (
    <svg className="w-5 h-3.5 rounded-sm overflow-hidden inline-block flex-shrink-0" viewBox="0 0 30 20">
      <rect width="30" height="20" fill="#FFF" />
      <rect width="30" height="6.67" fill="#FF9933" />
      <rect y="13.33" width="30" height="6.67" fill="#138808" />
      <circle cx="15" cy="10" r="2.5" fill="#000080" />
      <circle cx="15" cy="10" r="2.1" fill="#FFF" />
      <circle cx="15" cy="10" r="0.7" fill="#000080" />
    </svg>
  ),
  UsFlag: () => (
    <svg className="w-5 h-3.5 rounded-sm overflow-hidden inline-block flex-shrink-0" viewBox="0 0 30 20">
      <rect width="30" height="20" fill="#B22234" />
      <rect y="2" width="30" height="2" fill="#FFF" />
      <rect y="6" width="30" height="2" fill="#FFF" />
      <rect y="10" width="30" height="2" fill="#FFF" />
      <rect y="14" width="30" height="2" fill="#FFF" />
      <rect y="18" width="30" height="2" fill="#FFF" />
      <rect width="13" height="11" fill="#3C3B6E" />
    </svg>
  ),
  LogoGem: () => (
    <svg className="w-7 h-7 flex-shrink-0" viewBox="0 0 24 24" fill="none">
      <polygon points="12 2 2 8.5 12 15 22 8.5 12 2" fill="url(#gem-grad1)" />
      <polygon points="2 8.5 12 15 12 22 2 15.5 2 8.5" fill="url(#gem-grad2)" />
      <polygon points="22 8.5 12 15 12 22 22 15.5 22 8.5" fill="url(#gem-grad3)" />
      <defs>
        <linearGradient id="gem-grad1" x1="2" y1="2" x2="22" y2="15" gradientUnits="userSpaceOnUse">
          <stop stopColor="#60A5FA" />
          <stop offset="1" stopColor="#3B82F6" />
        </linearGradient>
        <linearGradient id="gem-grad2" x1="2" y1="8" x2="12" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E40AF" />
          <stop offset="1" stopColor="#1D4ED8" />
        </linearGradient>
        <linearGradient id="gem-grad3" x1="22" y1="8" x2="12" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#3B82F6" />
          <stop offset="1" stopColor="#1E3A8A" />
        </linearGradient>
      </defs>
    </svg>
  ),
  ShieldTrust: () => (
    <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
      <div className="absolute inset-0 bg-emerald-500/15 rounded-full blur-2xl beacon-pulse"></div>
      <svg className="w-24 h-24 text-emerald-400 drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="#0C1F1B" />
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
        <polyline points="9 12 11 14 15 9" stroke="#34D399" strokeWidth="2.2" />
      </svg>
      <div className="absolute top-2 right-4 w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#34D399]"></div>
      <div className="absolute bottom-3 left-4 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#22D3EE]"></div>
    </div>
  ),
  UpiLogo: () => (
    <div className="flex items-center gap-1 font-black text-xs tracking-wider">
      <span className="text-orange-500">U</span>
      <span className="text-white">P</span>
      <span className="text-emerald-500">I</span>
      <span className="text-[10px] text-gray-400">▶</span>
    </div>
  ),
  BankIcon: () => (
    <svg className="w-4 h-4 text-gray-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 21h18M3 10h18M5 10v11M9 10v11M15 10v11M19 10v11M12 2L2 7h20L12 2z" />
    </svg>
  ),
  CheckVerified: () => (
    <svg className="w-4 h-4 text-emerald-400 inline-block ml-1 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
    </svg>
  ),
  ChevronLeft: () => (
    <svg className="w-4 h-4 text-gray-300 hover:text-white transition" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="15 18 9 12 15 6" />
    </svg>
  ),
  ChevronDown: () => (
    <svg className="w-3.5 h-3.5 text-gray-400 ml-1 inline flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  ),
  Lock: () => (
    <svg className="w-3.5 h-3.5 text-emerald-400 inline mr-1 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  )
};

// ----------------------------------------------------
// Main App Component
// ----------------------------------------------------
function App() {
  // Navigation: 'quick-buy' | 'order-confirm' | 'merchant-onboard' | 'p2p-hub' | 'profile'
  const [currentPage, setCurrentPage] = useState('quick-buy');

  // Shared Trade State
  const [tradeType, setTradeType] = useState('BUY'); // 'BUY' | 'SELL'
  const [selectedCrypto, setSelectedCrypto] = useState('BTC'); // 'BTC' | 'ETH' | 'USDT' | 'SOL'
  const [fiatCurrency, setFiatCurrency] = useState('INR'); // 'INR' | 'USD' | 'EUR' | 'AED'
  const [payAmount, setPayAmount] = useState('70,000');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('P2P'); // 'UPI' | 'P2P'

  // Live Rates
  const [rates, setRates] = useState({
    INR: { BTC: 7705586.30, ETH: 284320.50, USDT: 90.25, SOL: 16420.00 },
    USD: { BTC: 92450.00, ETH: 3410.00, USDT: 1.00, SOL: 196.80 },
    EUR: { BTC: 85200.00, ETH: 3140.00, USDT: 0.92, SOL: 181.20 },
    AED: { BTC: 339500.00, ETH: 12520.00, USDT: 3.67, SOL: 722.50 }
  });

  // Database Records & Profile
  const [userProfile, setUserProfile] = useState(null);
  const [merchants, setMerchants] = useState([]);
  const [activeEscrowTrade, setActiveEscrowTrade] = useState(null);
  const [showFsdDrawer, setShowFsdDrawer] = useState(false);
  const [fsdSchema, setFsdSchema] = useState(null);
  const [toastMessage, setToastMessage] = useState(null);

  // Merchant Form State
  const [merchantForm, setMerchantForm] = useState({
    tradeName: '',
    securityDeposit: '500',
    supportedMethods: ['UPI', 'Bank Transfer'],
    minLimit: '10,000',
    maxLimit: '1,00,000'
  });

  useEffect(() => {
    fetchRates();
    fetchUserProfile();
    fetchMerchants('BTC', 'INR', 'BUY');
    fetchFsdSchema();
  }, []);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const fetchRates = async () => {
    try {
      const res = await fetch('/api/rates');
      const data = await res.json();
      if (data.success) setRates(data.rates);
    } catch (err) {
      console.warn('Using offline rates fallback', err);
    }
  };

  const fetchUserProfile = async () => {
    try {
      const res = await fetch('/api/user/profile');
      const data = await res.json();
      if (data.success) setUserProfile(data.user);
    } catch (err) {
      console.warn('Profile fetch warning', err);
    }
  };

  const fetchMerchants = async (crypto, fiat, type) => {
    try {
      const res = await fetch(`/api/merchants?crypto=${crypto}&fiat=${fiat}&type=${type}`);
      const data = await res.json();
      if (data.success) setMerchants(data.merchants);
    } catch (err) {
      console.warn('Merchants fetch warning', err);
    }
  };

  const fetchFsdSchema = async () => {
    try {
      const res = await fetch('/api/db/schema');
      const data = await res.json();
      if (data.success) setFsdSchema(data);
    } catch (err) {
      console.warn('Schema fetch warning', err);
    }
  };

  // Dynamic Numeric & Crypto Calculations
  const numericPay = useMemo(() => {
    const clean = String(payAmount).replace(/[^0-9.]/g, '');
    return parseFloat(clean) || 0;
  }, [payAmount]);

  const currentUnitRate = useMemo(() => {
    const cMap = rates[fiatCurrency] || rates.INR;
    return cMap[selectedCrypto] || 7705586.30;
  }, [rates, fiatCurrency, selectedCrypto]);

  const estimatedCrypto = useMemo(() => {
    if (numericPay <= 0 || currentUnitRate <= 0) return '0.00000000';
    const val = numericPay / currentUnitRate;
    return val < 1 ? val.toFixed(8) : val.toFixed(4);
  }, [numericPay, currentUnitRate]);

  // Initiate P2P Order with Escrow
  const handleInitiateOrder = async (merchant) => {
    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          merchantId: merchant?.id || 'merch_1',
          cryptoSymbol: selectedCrypto,
          fiatSymbol: fiatCurrency,
          fiatAmount: numericPay || 70000,
          cryptoAmount: parseFloat(estimatedCrypto) || 0.00905305,
          paymentMethod: selectedPaymentMethod === 'P2P' ? 'Peer-to-Peer (P2P)' : 'UPI'
        })
      });
      const data = await res.json();
      if (data.success) {
        setActiveEscrowTrade({
          order: data.order,
          merchant: merchant || merchants[0] || { trade_name: 'crypto_king', completion_rate: 99 },
          step: 1
        });
      }
    } catch (err) {
      showToast('Error initiating order: ' + err.message);
    }
  };

  // Submit Merchant Onboarding Form
  const handleMerchantSubmit = async (e) => {
    if (e) e.preventDefault();
    if (!merchantForm.tradeName.trim()) {
      showToast('Please enter a Merchant Trade Name');
      return;
    }

    try {
      const res = await fetch('/api/merchants/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tradeName: merchantForm.tradeName,
          securityDeposit: parseFloat(merchantForm.securityDeposit) || 500,
          supportedMethods: merchantForm.supportedMethods,
          minLimit: parseFloat(merchantForm.minLimit.replace(/,/g, '')) || 10000,
          maxLimit: parseFloat(merchantForm.maxLimit.replace(/,/g, '')) || 100000,
          cryptoSymbol: selectedCrypto,
          fiatSymbol: fiatCurrency
        })
      });
      const data = await res.json();
      if (data.success) {
        showToast('🎉 Application Approved! You are now a Verified P2P Merchant.');
        fetchUserProfile();
        fetchMerchants(selectedCrypto, fiatCurrency, tradeType);
        fetchFsdSchema();
        setTimeout(() => setCurrentPage('p2p-hub'), 1200);
      }
    } catch (err) {
      showToast('Onboarding failed: ' + err.message);
    }
  };

  // Escrow Pay & Auto-Release Simulation
  const handleMarkAsPaid = async () => {
    if (!activeEscrowTrade?.order?.id) return;
    try {
      const res = await fetch('/api/escrow/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId: activeEscrowTrade.order.id })
      });
      const data = await res.json();
      if (data.success) {
        setActiveEscrowTrade(prev => ({ ...prev, step: 2 }));
        showToast('Payment sent notification delivered to seller.');

        setTimeout(async () => {
          const relRes = await fetch('/api/escrow/release', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: activeEscrowTrade.order.id })
          });
          const relData = await relRes.json();
          if (relData.success) {
            setActiveEscrowTrade(prev => ({ ...prev, step: 3 }));
            fetchUserProfile();
            fetchFsdSchema();
            showToast(`✅ Escrow Released! Crypto transferred to your wallet.`);
          }
        }, 3200);
      }
    } catch (err) {
      showToast('Error marking payment: ' + err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#07090E] text-gray-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 transform -translate-x-1/2 z-[100] bg-blue-600 text-white px-6 py-3 rounded-2xl shadow-2xl backdrop-blur-md border border-blue-400/40 text-sm font-semibold flex items-center gap-2.5 animate-bounce">
          <span className="w-2.5 h-2.5 rounded-full bg-white"></span>
          {toastMessage}
        </div>
      )}

      {/* Top Live Crypto Price Ticker Bar */}
      <div className="bg-[#0B0F19] border-b border-white/5 py-1.5 px-4 overflow-hidden select-none text-[11px] text-gray-300">
        <div className="marquee-track flex items-center gap-10">
          <div className="flex items-center gap-8 font-mono-num whitespace-nowrap">
            <span className="flex items-center gap-1.5">
              <span className="text-amber-400 font-bold">BTC/INR:</span> ₹77,05,586.30 <span className="text-emerald-400 font-bold">+2.4%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-indigo-400 font-bold">ETH/INR:</span> ₹2,84,320.50 <span className="text-emerald-400 font-bold">+1.8%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-teal-400 font-bold">USDT/INR:</span> ₹90.25 <span className="text-gray-400 font-bold">0.0%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-purple-400 font-bold">SOL/INR:</span> ₹16,420.00 <span className="text-emerald-400 font-bold">+4.1%</span>
            </span>
            <span className="text-gray-500 font-sans">•</span>
            <span className="text-cyan-400 font-sans flex items-center gap-1">
              <span>🔒</span> Zero-Slippage P2P Escrow Vault: <strong className="text-emerald-400">100% Guaranteed</strong>
            </span>
            <span className="text-gray-500 font-sans">•</span>
            <span className="text-gray-400 font-sans">
              24h Volume: <strong className="text-white">₹14.8 Cr ($1.78M)</strong>
            </span>
          </div>

          {/* Duplicate track for seamless infinite scroll */}
          <div className="flex items-center gap-8 font-mono-num whitespace-nowrap">
            <span className="flex items-center gap-1.5">
              <span className="text-amber-400 font-bold">BTC/INR:</span> ₹77,05,586.30 <span className="text-emerald-400 font-bold">+2.4%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-indigo-400 font-bold">ETH/INR:</span> ₹2,84,320.50 <span className="text-emerald-400 font-bold">+1.8%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-teal-400 font-bold">USDT/INR:</span> ₹90.25 <span className="text-gray-400 font-bold">0.0%</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-purple-400 font-bold">SOL/INR:</span> ₹16,420.00 <span className="text-emerald-400 font-bold">+4.1%</span>
            </span>
            <span className="text-gray-500 font-sans">•</span>
            <span className="text-cyan-400 font-sans flex items-center gap-1">
              <span>🔒</span> Zero-Slippage P2P Escrow Vault: <strong className="text-emerald-400">100% Guaranteed</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Main Website Header / Navbar */}
      <header className="border-b border-white/10 bg-[#090D17]/90 backdrop-blur-xl sticky top-0 z-40 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
          {/* Brand Logo */}
          <div
            onClick={() => setCurrentPage('quick-buy')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="p-2 rounded-xl bg-blue-600/20 border border-blue-500/30 group-hover:scale-105 transition-all">
              <Icons.LogoGem />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg tracking-wider text-white">CRYPTO-COINBRIDGE</span>
                <span className="hidden sm:inline text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  P2P HUB
                </span>
              </div>
              <p className="text-[11px] text-gray-400 leading-tight">Instant Fiat On-Ramp & Escrow Engine</p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#101626] p-1.5 rounded-2xl border border-white/5">
            <button
              onClick={() => setCurrentPage('quick-buy')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                currentPage === 'quick-buy'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>⚡</span>
              <span>Quick Buy</span>
            </button>

            <button
              onClick={() => setCurrentPage('order-confirm')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                currentPage === 'order-confirm'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>💳</span>
              <span>Order Confirm</span>
            </button>

            <button
              onClick={() => setCurrentPage('p2p-hub')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                currentPage === 'p2p-hub'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>⇄</span>
              <span>P2P Trading Hub</span>
            </button>

            <button
              onClick={() => setCurrentPage('merchant-onboard')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                currentPage === 'merchant-onboard'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>🏛️</span>
              <span>Merchant Hub</span>
            </button>

            <button
              onClick={() => setCurrentPage('profile')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                currentPage === 'profile'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>👤</span>
              <span>Wallet & Escrow</span>
            </button>
          </nav>

          {/* Right Header Actions */}
          <div className="flex items-center gap-3">
            {/* FSD Schema Button */}
            <button
              onClick={() => setShowFsdDrawer(true)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-[#121A2D] hover:bg-[#1A2540] text-cyan-400 border border-cyan-500/30 transition shadow-sm"
            >
              <span>⚙️</span>
              <span>FSD Architecture & DB</span>
            </button>

            {/* User Wallet Badge */}
            {userProfile && (
              <div
                onClick={() => setCurrentPage('profile')}
                className="cursor-pointer bg-[#101726] hover:bg-[#152035] border border-white/10 px-3.5 py-1.5 rounded-2xl flex items-center gap-3 transition"
              >
                <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                  {userProfile.name?.charAt(0) || 'A'}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="text-[10px] text-gray-400 leading-tight">Wallet Balance</div>
                  <div className="font-mono-num font-extrabold text-xs text-emerald-400 leading-tight">
                    ₹{userProfile.fiat_balance?.toLocaleString('en-IN')}
                  </div>
                </div>
              </div>
            )}

            {/* Get Started Dropdown Button (Matching Screen 1 prompt spec) */}
            <GetStartedDropdown onNavigate={(page) => setCurrentPage(page)} />
          </div>
        </div>

        {/* Mobile Navigation Sub-Bar */}
        <div className="flex md:hidden items-center justify-around pt-3 border-t border-white/5 mt-2 text-xs">
          <button
            onClick={() => setCurrentPage('quick-buy')}
            className={`py-1 px-2 font-bold ${currentPage === 'quick-buy' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400'}`}
          >
            Quick Buy
          </button>
          <button
            onClick={() => setCurrentPage('order-confirm')}
            className={`py-1 px-2 font-bold ${currentPage === 'order-confirm' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400'}`}
          >
            Order
          </button>
          <button
            onClick={() => setCurrentPage('p2p-hub')}
            className={`py-1 px-2 font-bold ${currentPage === 'p2p-hub' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400'}`}
          >
            P2P Hub
          </button>
          <button
            onClick={() => setCurrentPage('merchant-onboard')}
            className={`py-1 px-2 font-bold ${currentPage === 'merchant-onboard' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400'}`}
          >
            Merchant
          </button>
          <button
            onClick={() => setCurrentPage('profile')}
            className={`py-1 px-2 font-bold ${currentPage === 'profile' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400'}`}
          >
            Wallet
          </button>
        </div>
      </header>

      {/* Main Page Content (Full Website Views) */}
      <main className="flex-1 flex flex-col page-fade-in">
        {currentPage === 'quick-buy' && (
          <WebPageQuickBuy
            tradeType={tradeType}
            setTradeType={setTradeType}
            selectedCrypto={selectedCrypto}
            setSelectedCrypto={setSelectedCrypto}
            rates={rates}
            onBuyNow={() => setCurrentPage('order-confirm')}
            onNavigate={(page) => setCurrentPage(page)}
          />
        )}

        {currentPage === 'order-confirm' && (
          <WebPageOrderConfirm
            fiatCurrency={fiatCurrency}
            setFiatCurrency={setFiatCurrency}
            payAmount={payAmount}
            setPayAmount={setPayAmount}
            selectedCrypto={selectedCrypto}
            setSelectedCrypto={setSelectedCrypto}
            estimatedCrypto={estimatedCrypto}
            currentUnitRate={currentUnitRate}
            selectedPaymentMethod={selectedPaymentMethod}
            setSelectedPaymentMethod={setSelectedPaymentMethod}
            onProceedToP2p={() => setCurrentPage('p2p-hub')}
            onBack={() => setCurrentPage('quick-buy')}
          />
        )}

        {currentPage === 'merchant-onboard' && (
          <WebPageMerchantOnboard
            merchantForm={merchantForm}
            setMerchantForm={setMerchantForm}
            onSubmit={handleMerchantSubmit}
            onBack={() => setCurrentPage('p2p-hub')}
          />
        )}

        {currentPage === 'p2p-hub' && (
          <WebPageP2pMarketplace
            tradeType={tradeType}
            setTradeType={setTradeType}
            selectedCrypto={selectedCrypto}
            setSelectedCrypto={setSelectedCrypto}
            fiatCurrency={fiatCurrency}
            setFiatCurrency={setFiatCurrency}
            merchants={merchants}
            onTradeClick={(m) => handleInitiateOrder(m)}
            onNavigate={(page) => setCurrentPage(page)}
          />
        )}

        {currentPage === 'profile' && (
          <WebPageProfile
            user={userProfile}
            onNavigate={(page) => setCurrentPage(page)}
          />
        )}
      </main>

      {/* Website Footer */}
      <footer className="border-t border-white/10 bg-[#06080E] py-10 px-6 mt-16 text-xs text-gray-400">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Icons.LogoGem />
              <span className="font-extrabold text-sm text-white tracking-wider">CRYPTO-COINBRIDGE</span>
            </div>
            <p className="text-gray-400 text-xs leading-relaxed max-w-sm">
              Next-generation crypto trading website featuring quick-buy fiat on-ramps and decentralized peer-to-peer (P2P) trading backed by smart escrow.
            </p>
            <div className="mt-4 flex items-center gap-2 text-[11px] text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>All Systems Operational • Node 24 SQLite Embedded</span>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">On-Ramp & Trading</h4>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => setCurrentPage('quick-buy')} className="hover:text-blue-400">Instant Buy BTC & ETH</button></li>
              <li><button onClick={() => setCurrentPage('order-confirm')} className="hover:text-blue-400">UPI Instant Fiat Checkout</button></li>
              <li><button onClick={() => setCurrentPage('p2p-hub')} className="hover:text-blue-400">P2P Trading Hub</button></li>
              <li><button onClick={() => setCurrentPage('merchant-onboard')} className="hover:text-blue-400">Become a P2P Merchant</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Security & Escrow</h4>
            <ul className="space-y-2 text-xs">
              <li><span className="text-gray-300">Fiat_Escrow Smart Engine</span></li>
              <li><span className="text-gray-300">100% Asset Lock Prior to Transfer</span></li>
              <li><span className="text-gray-300">Verified Merchant Security Deposits</span></li>
              <li><span className="text-gray-300">Dispute Arbitration Protocol</span></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">FSD Developer Portal</h4>
            <p className="text-gray-400 text-xs leading-relaxed mb-3">
              Feature-Sliced Design with SQLite database persistence, REST API routes, and live conversion walk.
            </p>
            <button
              onClick={() => setShowFsdDrawer(true)}
              className="px-4 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 font-bold border border-blue-500/30 text-xs transition"
            >
              View System Schema & DDL →
            </button>
          </div>
        </div>

        <div className="max-w-7xl mx-auto border-t border-white/5 mt-8 pt-6 flex flex-wrap items-center justify-between gap-4 text-[11px] text-gray-500">
          <div>© 2026 CRYPTO-COINBRIDGE Platform. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <span className="hover:text-gray-300">Privacy Policy</span>
            <span className="hover:text-gray-300">Terms of Escrow Service</span>
            <span className="hover:text-gray-300">Merchant Agreement</span>
          </div>
        </div>
      </footer>

      {/* Escrow Trade Simulation Modal */}
      {activeEscrowTrade && (
        <EscrowModal
          trade={activeEscrowTrade}
          onClose={() => setActiveEscrowTrade(null)}
          onMarkPaid={handleMarkAsPaid}
        />
      )}

      {/* FSD Architecture & DB Schema Drawer */}
      {showFsdDrawer && (
        <FsdDrawer
          schema={fsdSchema}
          onClose={() => setShowFsdDrawer(false)}
        />
      )}
    </div>
  );
}

// ----------------------------------------------------
// Get Started Dropdown Component (Screen 1 Spec)
// ----------------------------------------------------
function GetStartedDropdown({ onNavigate }) {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 shadow-md shadow-blue-600/25 transition active:scale-95"
      >
        <span>Get Started</span>
        <Icons.ChevronDown />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-52 rounded-2xl bg-[#111728] border border-white/10 shadow-2xl py-2 z-50 text-xs">
          <button
            onClick={() => { onNavigate('quick-buy'); setOpen(false); }}
            className="w-full text-left px-4 py-2.5 text-gray-200 hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
          >
            <span>⚡</span>
            <span>Instant Fiat On-Ramp</span>
          </button>
          <button
            onClick={() => { onNavigate('p2p-hub'); setOpen(false); }}
            className="w-full text-left px-4 py-2.5 text-gray-200 hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
          >
            <span>⇄</span>
            <span>P2P Trading Hub</span>
          </button>
          <button
            onClick={() => { onNavigate('merchant-onboard'); setOpen(false); }}
            className="w-full text-left px-4 py-2.5 text-gray-200 hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
          >
            <span>🏛️</span>
            <span>Apply as P2P Merchant</span>
          </button>
          <button
            onClick={() => { onNavigate('profile'); setOpen(false); }}
            className="w-full text-left px-4 py-2.5 text-gray-200 hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
          >
            <span>👤</span>
            <span>User Account & Wallet</span>
          </button>
          <div className="border-t border-white/5 my-1.5"></div>
          <div className="px-4 py-1 text-[11px] text-gray-500">
            Escrow Protected • v2.4
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// PAGE 1: Quick Buy (Landing Page - Website View)
// ----------------------------------------------------
function WebPageQuickBuy({ tradeType, setTradeType, selectedCrypto, setSelectedCrypto, rates, onBuyNow, onNavigate }) {
  const [showOtherModal, setShowOtherModal] = useState(false);

  return (
    <div className="w-full flex-1 flex flex-col items-center justify-center bg-radial-glow px-4 py-12 md:py-16">
      <div className="w-full max-w-6xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-16">
        {/* Left Column: Hero Copy & Value Props */}
        <div className="flex-1 text-center lg:text-left space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold tracking-wide">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
            <span>Instant fiat-to-crypto access in 75+ countries</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.15]">
            Buy, Sell & <br />
            <span className="text-gradient-blue">Swap Crypto</span> Instantly
          </h1>

          <p className="text-gray-400 text-sm sm:text-base max-w-xl mx-auto lg:mx-0 leading-relaxed">
            The fastest on-ramp to Bitcoin, Ethereum, and Tether with zero gateway cuts. Direct bank transfer, UPI settlement, and automated peer-to-peer escrow protection.
          </p>

          {/* Trust Highlights */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 max-w-lg mx-auto lg:mx-0 text-left">
            <div className="glass-card p-3.5 rounded-2xl border border-white/5">
              <div className="text-lg font-black text-white font-mono-num">₹0</div>
              <div className="text-[11px] text-gray-400 mt-0.5">Lowest Processing Fee</div>
            </div>
            <div className="glass-card p-3.5 rounded-2xl border border-white/5">
              <div className="text-lg font-black text-emerald-400 font-mono-num">&lt; 3 mins</div>
              <div className="text-[11px] text-gray-400 mt-0.5">Instant Settlement</div>
            </div>
            <div className="glass-card p-3.5 rounded-2xl border border-white/5 col-span-2 sm:col-span-1">
              <div className="text-lg font-black text-cyan-400 font-mono-num">100%</div>
              <div className="text-[11px] text-gray-400 mt-0.5">Escrow Guaranteed</div>
            </div>
          </div>
        </div>

        {/* Right Column: Core Card (Matching Screen 1 Specs) */}
        <div className="w-full max-w-md flex-shrink-0">
          <div className="glass-card p-6 sm:p-7 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden backdrop-blur-2xl">
            {/* Top Glow Accent */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-indigo-500"></div>

            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Fast Swap Terminal</span>
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <Icons.Lock /> Bank Grade Security
              </span>
            </div>

            {/* Segmented Buy / Sell Toggle Tabs */}
            <div className="bg-[#0B0F19] p-1.5 rounded-2xl flex items-center border border-white/5">
              <button
                onClick={() => setTradeType('BUY')}
                className={`flex-1 py-2.5 text-xs font-extrabold rounded-xl transition-all ${
                  tradeType === 'BUY'
                    ? 'bg-[#18233C] text-blue-400 border border-blue-500/50 shadow-inner'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Buy
              </button>
              <button
                onClick={() => setTradeType('SELL')}
                className={`flex-1 py-2.5 text-xs font-extrabold rounded-xl transition-all ${
                  tradeType === 'SELL'
                    ? 'bg-[#18233C] text-red-400 border border-red-500/50 shadow-inner'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Sell
              </button>
            </div>

            {/* Quick Crypto Options 2x2 Grid */}
            <div className="grid grid-cols-2 gap-3 mt-5">
              {/* BTC (Orange Icon, Active by default) */}
              <button
                onClick={() => setSelectedCrypto('BTC')}
                className={`p-3.5 rounded-2xl border flex items-center gap-3 text-xs font-bold transition-all ${
                  selectedCrypto === 'BTC'
                    ? 'bg-[#1A2338] border-blue-500/80 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] ring-1 ring-blue-500/60'
                    : 'bg-[#0E1422] border-white/5 text-gray-300 hover:border-white/20'
                }`}
              >
                <Icons.Btc />
                <div className="text-left">
                  <div className="font-extrabold text-white">BTC</div>
                  <div className="text-[10px] text-gray-400 font-normal">Bitcoin</div>
                </div>
              </button>

              {/* ETH */}
              <button
                onClick={() => setSelectedCrypto('ETH')}
                className={`p-3.5 rounded-2xl border flex items-center gap-3 text-xs font-bold transition-all ${
                  selectedCrypto === 'ETH'
                    ? 'bg-[#1A2338] border-blue-500/80 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] ring-1 ring-blue-500/60'
                    : 'bg-[#0E1422] border-white/5 text-gray-300 hover:border-white/20'
                }`}
              >
                <Icons.Eth />
                <div className="text-left">
                  <div className="font-extrabold text-white">ETH</div>
                  <div className="text-[10px] text-gray-400 font-normal">Ethereum</div>
                </div>
              </button>

              {/* USDT */}
              <button
                onClick={() => setSelectedCrypto('USDT')}
                className={`p-3.5 rounded-2xl border flex items-center gap-3 text-xs font-bold transition-all ${
                  selectedCrypto === 'USDT'
                    ? 'bg-[#1A2338] border-blue-500/80 text-white shadow-[0_0_20px_rgba(37,99,235,0.3)] ring-1 ring-blue-500/60'
                    : 'bg-[#0E1422] border-white/5 text-gray-300 hover:border-white/20'
                }`}
              >
                <Icons.Usdt />
                <div className="text-left">
                  <div className="font-extrabold text-white">USDT</div>
                  <div className="text-[10px] text-gray-400 font-normal">Tether USD</div>
                </div>
              </button>

              {/* Other */}
              <button
                onClick={() => setShowOtherModal(true)}
                className={`p-3.5 rounded-2xl border flex items-center justify-between text-xs font-bold transition-all ${
                  ['SOL', 'ADA', 'XRP'].includes(selectedCrypto)
                    ? 'bg-[#1A2338] border-blue-500/80 text-white shadow-sm'
                    : 'bg-[#0E1422] border-white/5 text-gray-300 hover:border-white/20'
                }`}
              >
                <div className="text-left">
                  <div className="font-extrabold text-white">
                    {['SOL', 'ADA', 'XRP'].includes(selectedCrypto) ? selectedCrypto : 'Other'}
                  </div>
                  <div className="text-[10px] text-gray-400 font-normal">Select token</div>
                </div>
                <Icons.ChevronDown />
              </button>
            </div>

            {/* Prominent Blue Buy Now Button */}
            <button
              onClick={onBuyNow}
              className="w-full mt-6 py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 active:scale-[0.99] text-white font-extrabold text-sm tracking-wide shadow-xl shadow-blue-600/35 transition-all flex items-center justify-center gap-2 glow-blue"
            >
              <span>{tradeType === 'BUY' ? 'Buy Now' : 'Sell Now'}</span>
              <span className="text-base">→</span>
            </button>

            {/* Trust Badges */}
            <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-center gap-3 text-xs text-gray-400">
              <span className="flex items-center gap-1.5">
                <span className="text-blue-400 font-extrabold">%</span> Lowest processing fee
              </span>
              <span className="text-gray-600">•</span>
              <span className="flex items-center gap-1.5">
                <Icons.Lock /> Secure & instant transactions
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Select Other Token Modal */}
      {showOtherModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#101728] border border-white/10 rounded-3xl p-5 w-full max-w-xs shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="font-bold text-sm text-white">Select Alternate Asset</span>
              <button onClick={() => setShowOtherModal(false)} className="text-gray-400 hover:text-white text-sm">✕</button>
            </div>
            <div className="divide-y divide-white/5 mt-3">
              {[
                { sym: 'SOL', name: 'Solana', icon: '🟣' },
                { sym: 'ADA', name: 'Cardano', icon: '🔵' },
                { sym: 'XRP', name: 'Ripple', icon: '⚪' }
              ].map(item => (
                <button
                  key={item.sym}
                  onClick={() => {
                    setSelectedCrypto(item.sym);
                    setShowOtherModal(false);
                  }}
                  className="w-full py-3 flex items-center justify-between text-xs text-left hover:bg-white/5 px-2.5 rounded-xl transition"
                >
                  <span className="flex items-center gap-2 text-white font-bold">
                    <span>{item.icon}</span> {item.sym}
                  </span>
                  <span className="text-gray-400">{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ----------------------------------------------------
// PAGE 2: Order Confirmation (With P2P Integration - Website View)
// ----------------------------------------------------
function WebPageOrderConfirm({
  fiatCurrency, setFiatCurrency,
  payAmount, setPayAmount,
  selectedCrypto, setSelectedCrypto,
  estimatedCrypto, currentUnitRate,
  selectedPaymentMethod, setSelectedPaymentMethod,
  onProceedToP2p, onBack
}) {
  const [fiatDropdownOpen, setFiatDropdownOpen] = useState(false);
  const [cryptoDropdownOpen, setCryptoDropdownOpen] = useState(false);

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 md:py-12 flex-1">
      {/* Breadcrumb Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-semibold text-gray-400 hover:text-white transition mb-6"
      >
        <Icons.ChevronLeft />
        <span>Back to Quick Buy</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Order Inputs & Payment Method (Specs Screen 2) */}
        <div className="lg:col-span-7 glass-card p-6 sm:p-8 rounded-3xl border border-white/10 shadow-2xl">
          <div className="border-b border-white/10 pb-4 mb-6">
            <h2 className="text-xl font-extrabold text-white tracking-tight">Quick Buy Order</h2>
            <p className="text-xs text-gray-400 mt-1">Review conversion rates and select your preferred settlement method.</p>
          </div>

          <div className="space-y-5">
            {/* Pay Field */}
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-2">Pay</label>
              <div className="bg-[#0B0F19] border border-white/10 rounded-2xl p-4 flex items-center justify-between focus-within:border-blue-500/70 transition">
                <input
                  type="text"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="bg-transparent text-2xl font-black text-white font-mono-num w-full focus:outline-none"
                  placeholder="70,000"
                />

                {/* Fiat Picker */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setFiatDropdownOpen(!fiatDropdownOpen)}
                    className="bg-[#172033] hover:bg-[#202C46] border border-white/10 text-white text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-2 transition select-none"
                  >
                    <Icons.IndiaFlag />
                    <span>{fiatCurrency}</span>
                    <Icons.ChevronDown />
                  </button>

                  {fiatDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-32 rounded-2xl bg-[#141B2C] border border-white/10 shadow-2xl py-1.5 z-40 text-xs">
                      {['INR', 'USD', 'EUR', 'AED'].map(curr => (
                        <button
                          key={curr}
                          onClick={() => { setFiatCurrency(curr); setFiatDropdownOpen(false); }}
                          className="w-full text-left px-3.5 py-2 text-gray-300 hover:bg-blue-600/20 hover:text-white flex items-center justify-between"
                        >
                          <span>{curr}</span>
                          {curr === 'INR' && <Icons.IndiaFlag />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* You Get Field */}
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-2">You get</label>
              <div className="bg-[#0B0F19] border border-white/10 rounded-2xl p-4 flex items-center justify-between focus-within:border-blue-500/70 transition">
                <input
                  type="text"
                  readOnly
                  value={estimatedCrypto}
                  className="bg-transparent text-2xl font-black text-white font-mono-num w-full focus:outline-none"
                />

                {/* Crypto Picker */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setCryptoDropdownOpen(!cryptoDropdownOpen)}
                    className="bg-[#172033] hover:bg-[#202C46] border border-white/10 text-white text-xs font-bold px-3.5 py-2 rounded-xl flex items-center gap-2 transition select-none"
                  >
                    {selectedCrypto === 'BTC' && <Icons.Btc />}
                    {selectedCrypto === 'ETH' && <Icons.Eth />}
                    {selectedCrypto === 'USDT' && <Icons.Usdt />}
                    <span>{selectedCrypto}</span>
                    <Icons.ChevronDown />
                  </button>

                  {cryptoDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-32 rounded-2xl bg-[#141B2C] border border-white/10 shadow-2xl py-1.5 z-40 text-xs">
                      {['BTC', 'ETH', 'USDT'].map(sym => (
                        <button
                          key={sym}
                          onClick={() => { setSelectedCrypto(sym); setCryptoDropdownOpen(false); }}
                          className="w-full text-left px-3.5 py-2 text-gray-300 hover:bg-blue-600/20 hover:text-white flex items-center gap-2"
                        >
                          {sym === 'BTC' && <Icons.Btc />}
                          {sym === 'ETH' && <Icons.Eth />}
                          {sym === 'USDT' && <Icons.Usdt />}
                          <span>{sym}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Conversion Rate Footnote */}
              <div className="text-xs text-gray-400 font-mono-num mt-2 px-1 flex items-center justify-between">
                <span>
                  1 {selectedCrypto} = {fiatCurrency === 'INR' ? '₹' : '$'}
                  {currentUnitRate.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                </span>
                <span className="text-[11px] text-emerald-400 font-bold">Guaranteed Rate</span>
              </div>
            </div>

            {/* Payment Method Section */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-gray-300 mb-3">Payment Method</label>

              <div className="space-y-3">
                {/* Option A: UPI */}
                <div
                  onClick={() => setSelectedPaymentMethod('UPI')}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    selectedPaymentMethod === 'UPI'
                      ? 'bg-[#141C2E] border-blue-500/80 shadow-md ring-1 ring-blue-500/40'
                      : 'bg-[#0B0F19] border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center">
                      <Icons.UpiLogo />
                    </div>
                    <div>
                      <div className="text-sm font-extrabold text-white">UPI</div>
                      <div className="text-xs text-gray-400">PhonePe, GPay, Paytm, etc</div>
                    </div>
                  </div>
                  <Icons.ChevronDown />
                </div>

                {/* Option B: Highlighted P2P (Specs Screen 2) */}
                <div
                  onClick={() => setSelectedPaymentMethod('P2P')}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all relative overflow-hidden ${
                    selectedPaymentMethod === 'P2P'
                      ? 'bg-[#0A1B1F] border-emerald-500/80 shadow-[0_0_25px_rgba(16,185,129,0.25)] ring-1 ring-emerald-500/60'
                      : 'bg-[#0B0F19] border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3.5">
                      <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                          <circle cx="9" cy="7" r="4" />
                          <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                          <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                        </svg>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-black text-white">Peer-to-Peer (P2P)</span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                            Zero Fees
                          </span>
                        </div>
                        <div className="text-xs text-gray-400 mt-0.5">
                          Buy directly from verified P2P Merchants
                        </div>
                      </div>
                    </div>

                    <div className="w-6 h-6 rounded-full bg-emerald-500 text-black flex items-center justify-center text-xs font-black">
                      ✓
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Button: Proceed to P2P */}
            <button
              onClick={onProceedToP2p}
              className="w-full mt-4 py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 active:scale-[0.99] text-white font-extrabold text-sm tracking-wide shadow-xl shadow-blue-600/35 transition-all flex items-center justify-center gap-2 glow-blue"
            >
              <span>Proceed to P2P</span>
              <span className="text-base">→</span>
            </button>
          </div>
        </div>

        {/* Right Column: Escrow Guarantee & Settlement Checklist */}
        <div className="lg:col-span-5 space-y-6">
          <div className="glass-card p-6 sm:p-7 rounded-3xl border border-white/10 shadow-xl">
            <h3 className="font-extrabold text-base text-white mb-4 flex items-center gap-2">
              <span className="text-emerald-400">🛡️</span> Escrow Protection Guarantee
            </h3>

            <div className="space-y-4 text-xs text-gray-300">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
                  1
                </div>
                <div>
                  <div className="font-bold text-white">Crypto Pre-Locked in Escrow</div>
                  <div className="text-gray-400 text-[11px] mt-0.5">
                    The merchant's crypto is locked in the smart escrow contract the moment you proceed.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
                  2
                </div>
                <div>
                  <div className="font-bold text-white">Direct Local Settlement</div>
                  <div className="text-gray-400 text-[11px] mt-0.5">
                    Pay using your preferred app (GPay, PhonePe, Bank Transfer) with zero intermediary cuts.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold flex-shrink-0 mt-0.5">
                  3
                </div>
                <div>
                  <div className="font-bold text-white">Instant Wallet Deposit</div>
                  <div className="text-gray-400 text-[11px] mt-0.5">
                    Once the merchant confirms fiat receipt, crypto is instantly transferred to your wallet.
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-white/5 bg-[#0B0F19] -mx-6 -mb-6 p-6 rounded-b-3xl">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">Estimated Delivery:</span>
                <span className="font-mono-num font-bold text-white">&lt; 3 minutes</span>
              </div>
              <div className="flex items-center justify-between text-xs mt-2">
                <span className="text-gray-400">Trading Fee:</span>
                <span className="font-mono-num font-bold text-emerald-400">₹0.00 (Free)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// PAGE 3: P2P Merchant Onboarding (Website View)
// ----------------------------------------------------
function WebPageMerchantOnboard({ merchantForm, setMerchantForm, onSubmit, onBack }) {
  const toggleMethod = (method) => {
    const current = merchantForm.supportedMethods || [];
    if (current.includes(method)) {
      if (current.length > 1) {
        setMerchantForm({ ...merchantForm, supportedMethods: current.filter(m => m !== method) });
      }
    } else {
      setMerchantForm({ ...merchantForm, supportedMethods: [...current, method] });
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 md:py-12 flex-1">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-semibold text-gray-400 hover:text-white transition mb-6"
      >
        <Icons.ChevronLeft />
        <span>Back to P2P Trading Hub</span>
      </button>

      <div className="glass-card p-8 sm:p-10 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-1/4 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="text-center max-w-xl mx-auto mb-8">
          {/* Security Shield Illustration (Specs Screen 3) */}
          <Icons.ShieldTrust />

          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-4">
            P2P Merchant Onboarding
          </h2>
          <p className="text-sm text-gray-400 mt-2 leading-relaxed">
            Apply to become a P2P Merchant & Earn by facilitating local buy and sell orders. Join over 2,400+ verified liquidity providers.
          </p>
        </div>

        {/* Application Form */}
        <form onSubmit={onSubmit} className="max-w-lg mx-auto space-y-5">
          {/* Merchant Trade Name */}
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-2">Merchant</label>
            <input
              type="text"
              required
              placeholder="Merchant Trade Name (e.g. crypto_pro_desk)"
              value={merchantForm.tradeName}
              onChange={(e) => setMerchantForm({ ...merchantForm, tradeName: e.target.value })}
              className="w-full bg-[#0B0F19] border border-white/10 rounded-2xl px-4 py-3.5 text-sm text-white placeholder-gray-500 focus:border-blue-500/80 focus:ring-1 focus:ring-blue-500/60 transition font-medium"
            />
          </div>

          {/* Security Deposit */}
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-2">
              Security Deposit (e.g., USDT)
            </label>
            <input
              type="text"
              placeholder="Security Deposit Name / Amount (e.g., 500 USDT)"
              value={merchantForm.securityDeposit}
              onChange={(e) => setMerchantForm({ ...merchantForm, securityDeposit: e.target.value })}
              className="w-full bg-[#0B0F19] border border-white/10 rounded-2xl px-4 py-3.5 text-sm text-white placeholder-gray-500 focus:border-blue-500/80 focus:ring-1 focus:ring-blue-500/60 transition font-medium font-mono-num"
            />
          </div>

          {/* Payment Methods Supported */}
          <div>
            <label className="block text-xs font-bold text-gray-300 mb-2.5">
              Payment Methods Supported
            </label>
            <div className="grid grid-cols-2 gap-3">
              {/* UPI */}
              <button
                type="button"
                onClick={() => toggleMethod('UPI')}
                className={`py-3.5 px-4 rounded-2xl border flex items-center justify-center gap-2 text-xs font-bold transition-all ${
                  merchantForm.supportedMethods.includes('UPI')
                    ? 'bg-[#18233C] border-blue-500/80 text-white shadow-sm ring-1 ring-blue-500/60'
                    : 'bg-[#0B0F19] border-white/5 text-gray-400 hover:border-white/20'
                }`}
              >
                <Icons.UpiLogo />
              </button>

              {/* Bank Transfer */}
              <button
                type="button"
                onClick={() => toggleMethod('Bank Transfer')}
                className={`py-3.5 px-4 rounded-2xl border flex items-center justify-center gap-2 text-xs font-bold transition-all ${
                  merchantForm.supportedMethods.includes('Bank Transfer')
                    ? 'bg-[#18233C] border-blue-500/80 text-white shadow-sm ring-1 ring-blue-500/60'
                    : 'bg-[#0B0F19] border-white/5 text-gray-400 hover:border-white/20'
                }`}
              >
                <Icons.BankIcon />
                <span>Bank Transfer</span>
              </button>
            </div>
          </div>

          {/* CTA */}
          <button
            type="submit"
            className="w-full mt-4 py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 active:scale-[0.99] text-white font-extrabold text-sm tracking-wide shadow-xl shadow-blue-600/35 transition-all flex items-center justify-center gap-2 glow-blue"
          >
            <span>Submit Application & Create P2P Merchant Account</span>
          </button>

          {/* Footnote (Specs Screen 3) */}
          <p className="text-xs text-gray-400 text-center mt-4 leading-relaxed">
            Normal users can buy and sell instantly without merchant registration
          </p>
        </form>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// PAGE 4: P2P Marketplace (Website View)
// ----------------------------------------------------
function WebPageP2pMarketplace({
  tradeType, setTradeType,
  selectedCrypto, setSelectedCrypto,
  fiatCurrency, setFiatCurrency,
  merchants, onTradeClick, onNavigate
}) {
  const filteredMerchants = useMemo(() => {
    return merchants.filter(m => {
      const matchCrypto = !selectedCrypto || m.crypto_symbol === selectedCrypto;
      const matchType = !tradeType || m.trade_type === tradeType;
      return matchCrypto && matchType;
    });
  }, [merchants, selectedCrypto, tradeType]);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-8 md:py-12 flex-1">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
            <span>P2P Trading Hub</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Live Feed
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-gray-400 mt-1">
            Buy and sell cryptocurrency directly with verified users & merchants with 0% escrow fees.
          </p>
        </div>

        <button
          onClick={() => onNavigate('merchant-onboard')}
          className="self-start md:self-auto px-4 py-2.5 rounded-xl bg-[#141E34] hover:bg-[#1C2B4A] text-cyan-400 border border-cyan-500/30 text-xs font-bold transition flex items-center gap-2 shadow-sm"
        >
          <span>🏛️</span>
          <span>Post Your Buy/Sell Ad</span>
        </button>
      </div>

      {/* Filter Toolbar (Specs Screen 4) */}
      <div className="my-6 glass-card p-4 rounded-2xl border border-white/10 flex flex-wrap items-center justify-between gap-4">
        {/* Buy / Sell Tabs */}
        <div className="bg-[#0B0F19] p-1 rounded-xl flex items-center border border-white/5 w-44">
          <button
            onClick={() => setTradeType('BUY')}
            className={`flex-1 py-2 text-xs font-extrabold rounded-lg transition-all ${
              tradeType === 'BUY'
                ? 'bg-[#18233C] text-blue-400 border border-blue-500/40 shadow-inner'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Buy
          </button>
          <button
            onClick={() => setTradeType('SELL')}
            className={`flex-1 py-2 text-xs font-extrabold rounded-lg transition-all ${
              tradeType === 'SELL'
                ? 'bg-[#18233C] text-red-400 border border-red-500/40 shadow-inner'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Sell
          </button>
        </div>

        {/* Crypto Filters */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-gray-400 hidden sm:inline">Crypto:</span>
          {['BTC', 'USDT', 'ETH'].map(sym => (
            <button
              key={sym}
              onClick={() => setSelectedCrypto(sym)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition ${
                selectedCrypto === sym
                  ? 'bg-[#1A2338] border-blue-500/80 text-white shadow-sm ring-1 ring-blue-500/50'
                  : 'bg-[#0E1422] border-white/5 text-gray-400 hover:border-white/20'
              }`}
            >
              {sym === 'BTC' && <Icons.Btc />}
              {sym === 'USDT' && <Icons.Usdt />}
              {sym === 'ETH' && <Icons.Eth />}
              <span>{sym}</span>
            </button>
          ))}
        </div>

        {/* Fiat Currency Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-gray-400 hidden sm:inline">Fiat:</span>
          <div className="bg-[#0E1422] border border-white/10 px-3 py-1.5 rounded-xl text-xs font-bold text-white flex items-center gap-2">
            <Icons.IndiaFlag />
            <span>INR (₹)</span>
          </div>
        </div>
      </div>

      {/* Listing Feed: Merchant Table / Cards */}
      <div className="space-y-4">
        {filteredMerchants.length === 0 ? (
          <div className="glass-card p-12 text-center rounded-3xl border border-white/5 text-gray-400">
            <div className="text-3xl mb-2">🔍</div>
            <div className="font-bold text-white text-base">No merchants found for this filter</div>
            <div className="text-xs mt-1">Try switching between Buy and Sell or selecting BTC / USDT.</div>
          </div>
        ) : (
          filteredMerchants.map(merchant => (
            <WebMerchantRow
              key={merchant.id}
              merchant={merchant}
              tradeType={tradeType}
              selectedCrypto={selectedCrypto}
              onAction={() => onTradeClick(merchant)}
            />
          ))
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Merchant Card / Row Component (Specs Screen 4)
// ----------------------------------------------------
function WebMerchantRow({ merchant, tradeType, selectedCrypto, onAction }) {
  const isBuy = tradeType === 'BUY';
  const priceDisplay = merchant.price_inr
    ? `₹${merchant.price_inr.toLocaleString('en-IN')}`
    : `₹77,10,000`;

  return (
    <div className="glass-card p-5 sm:p-6 rounded-2xl border border-white/10 shadow-lg hover:border-white/20 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6">
      {/* Merchant Info & Completion */}
      <div className="md:w-1/3">
        <div className="flex items-center gap-2">
          {merchant.trade_name === 'crypto_king' ? (
            <span className="text-amber-400 text-lg">👑</span>
          ) : (
            <div className="w-6 h-6 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold text-xs">
              ⇄
            </div>
          )}
          <span className="font-extrabold text-base text-white tracking-wide">{merchant.trade_name}</span>
          <span className="text-xs text-gray-400 font-mono-num">
            ({merchant.completion_rate || 99}% completion)
          </span>
          {merchant.is_verified && <Icons.CheckVerified />}
        </div>

        {/* Completion Progress Bar */}
        <div className="w-48 bg-[#1A2234] h-1.5 rounded-full mt-2.5 overflow-hidden">
          <div
            className="bg-emerald-400 h-full rounded-full"
            style={{ width: `${merchant.completion_rate || 99}%` }}
          ></div>
        </div>

        <div className="text-[11px] text-gray-400 mt-2 font-mono-num">
          {merchant.total_trades || 428} orders executed • 100% Escrow deposit
        </div>
      </div>

      {/* Price & Limits */}
      <div className="md:w-1/3 space-y-1">
        <div className="text-xs text-gray-400 font-semibold">Price:</div>
        <div className="text-xl font-black text-white font-mono-num tracking-tight">
          {priceDisplay}
        </div>
        <div className="text-xs text-gray-400 font-mono-num">
          Limits: ₹{merchant.min_limit?.toLocaleString('en-IN')} - ₹{merchant.max_limit?.toLocaleString('en-IN')}
        </div>
      </div>

      {/* Payment Methods & Action Button */}
      <div className="md:w-1/3 flex flex-col sm:flex-row items-start sm:items-center justify-end gap-4">
        <div className="flex flex-wrap items-center gap-1.5">
          {(merchant.supported_methods || ['UPI']).map((m, idx) => (
            <span key={idx} className="px-2.5 py-1 rounded-lg bg-[#141C2E] border border-white/10 text-xs font-semibold text-gray-300">
              {m}
            </span>
          ))}
        </div>

        <button
          onClick={onAction}
          className={`px-6 py-3 rounded-xl font-extrabold text-xs tracking-wide shadow-lg transition-all active:scale-95 flex-shrink-0 ${
            isBuy
              ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/25 glow-green'
              : 'bg-red-500 hover:bg-red-400 text-white shadow-red-500/25'
          }`}
        >
          {isBuy ? `Buy ${selectedCrypto || 'BTC'}` : `Sell ${selectedCrypto || 'BTC'}`}
        </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// PAGE 5: Profile / Wallet & Escrow Ledger (Website View)
// ----------------------------------------------------
function WebPageProfile({ user, onNavigate }) {
  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8 md:py-12 flex-1">
      <div className="flex items-center justify-between pb-6 border-b border-white/10 mb-8">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">User Account & Wallet</h1>
          <p className="text-xs text-gray-400 mt-1">Manage balances, active escrow orders, and merchant permissions.</p>
        </div>
        <button
          onClick={() => onNavigate('quick-buy')}
          className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
        >
          New Quick Buy →
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* User Card */}
        <div className="glass-card p-6 rounded-3xl border border-white/10 md:col-span-1 space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center font-black text-2xl text-white shadow-xl">
            {user?.name?.charAt(0) || 'A'}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-base text-white">{user?.name || 'Alex Rivera'}</h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                {user?.role || 'USER'}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">{user?.email || 'trader@cryptocoinbridge.io'}</p>
          </div>

          <div className="pt-4 border-t border-white/5 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-400">KYC Status:</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <Icons.CheckVerified /> Verified
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Escrow Security:</span>
              <span className="text-white font-mono-num font-semibold">Tier 3 (Max)</span>
            </div>
          </div>
        </div>

        {/* Balances Grid */}
        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="glass-card p-5 rounded-2xl border border-white/5">
            <span className="text-xs text-gray-400 font-semibold block">Fiat Balance (INR)</span>
            <span className="font-black text-2xl text-white font-mono-num mt-2 block">
              ₹{user?.fiat_balance?.toLocaleString('en-IN') || '1,50,000'}
            </span>
            <span className="text-[11px] text-gray-400 mt-1 block">Available for instant UPI on-ramp</span>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-white/5">
            <span className="text-xs text-gray-400 font-semibold block">Bitcoin (BTC)</span>
            <span className="font-black text-2xl text-amber-400 font-mono-num mt-2 block">
              {user?.btc_balance?.toFixed(6) || '0.045000'} BTC
            </span>
            <span className="text-[11px] text-gray-400 mt-1 block">≈ ₹3,46,751.38 INR</span>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-white/5">
            <span className="text-xs text-gray-400 font-semibold block">Tether (USDT)</span>
            <span className="font-black text-2xl text-emerald-400 font-mono-num mt-2 block">
              {user?.usdt_balance?.toFixed(2) || '2,500.00'} USDT
            </span>
            <span className="text-[11px] text-gray-400 mt-1 block">≈ ₹2,25,625.00 INR</span>
          </div>

          <div className="glass-card p-5 rounded-2xl border border-white/5">
            <span className="text-xs text-gray-400 font-semibold block">Ethereum (ETH)</span>
            <span className="font-black text-2xl text-indigo-400 font-mono-num mt-2 block">
              {user?.eth_balance?.toFixed(4) || '1.2500'} ETH
            </span>
            <span className="text-[11px] text-gray-400 mt-1 block">≈ ₹3,55,400.62 INR</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Escrow Modal Flow
// ----------------------------------------------------
function EscrowModal({ trade, onClose, onMarkPaid }) {
  const { order, merchant, step } = trade;

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#0D1322] border border-blue-500/30 rounded-3xl max-w-md w-full p-6 shadow-2xl relative overflow-hidden">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div>
            <div className="text-xs font-mono-num text-blue-400 font-bold">
              {order?.orderNo || 'P2P-74918234'}
            </div>
            <div className="text-xs text-gray-400 mt-0.5">
              Escrow Smart Trade with <span className="text-white font-semibold">@{merchant?.trade_name}</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10">
            ✕
          </button>
        </div>

        <div className="my-5 space-y-4">
          <div className="bg-[#10182A] border border-emerald-500/30 rounded-2xl p-4 flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <svg className="w-6 h-6 animate-pulse" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
            <div>
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <span>Crypto Secured in Smart Escrow</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              <div className="text-sm text-gray-200 font-mono-num font-bold mt-0.5">
                {order?.cryptoAmount?.toFixed(8)} {order?.cryptoSymbol || 'BTC'}
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#0B0F19] border border-white/5 space-y-2.5 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-400">Fiat Payable:</span>
              <span className="font-extrabold text-white font-mono-num text-sm">
                ₹{order?.fiatAmount?.toLocaleString('en-IN') || '70,000'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Merchant UPI ID:</span>
              <span className="font-mono-num text-cyan-400 font-semibold flex items-center gap-1 select-all cursor-pointer">
                cryptoking@okaxis 📋
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Time Remaining:</span>
              <span className="font-mono-num text-amber-400 font-bold">14:55 min</span>
            </div>
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-2.5">
            <button
              onClick={onMarkPaid}
              className="w-full py-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs tracking-wide shadow-xl shadow-blue-600/35 flex items-center justify-center gap-2 transition"
            >
              <span>I Have Transferred INR (Mark as Paid)</span>
              <span>→</span>
            </button>
            <p className="text-[11px] text-gray-400 text-center">
              Please pay via your UPI app (PhonePe/GPay) before clicking confirm.
            </p>
          </div>
        )}

        {step === 2 && (
          <div className="text-center py-4 space-y-3">
            <div className="w-10 h-10 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <div>
              <div className="text-sm font-bold text-white">Payment Notification Sent!</div>
              <div className="text-xs text-gray-400 mt-1">
                Merchant @{merchant?.trade_name} is verifying receipt. Escrow will release automatically.
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="text-center py-4 space-y-3">
            <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center text-xl mx-auto shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              ✓
            </div>
            <div>
              <div className="text-base font-black text-white">Order Completed!</div>
              <div className="text-xs text-emerald-400 font-mono-num mt-1">
                +{order?.cryptoAmount?.toFixed(8)} {order?.cryptoSymbol || 'BTC'} deposited to wallet.
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-full mt-3 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs transition"
            >
              Done & View Balance
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------
// FSD Architecture & DB Schema Drawer
// ----------------------------------------------------
function FsdDrawer({ schema, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex justify-end">
      <div className="bg-[#0B0F1A] border-l border-white/10 w-full max-w-xl h-full overflow-y-auto p-6 sm:p-8 shadow-2xl flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="font-extrabold text-base text-white">
                FSD System Architecture & Database
              </h3>
              <p className="text-xs text-gray-400">
                Feature-Sliced Design specification & SQLite embedded tables
              </p>
            </div>
            <button onClick={onClose} className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/10">
              ✕
            </button>
          </div>

          <div className="space-y-6 mt-6 text-xs">
            {/* Escrow Mechanism Explanation */}
            <div className="bg-[#111726] p-4 rounded-2xl border border-blue-500/30">
              <div className="font-bold text-sm text-cyan-400 mb-2 flex items-center gap-2">
                <span>🔒</span> Escrow Protocol Security Logic
              </div>
              <p className="text-gray-300 leading-relaxed text-[11px]">
                To prevent fraud in peer-to-peer trading, the protocol locks the seller's cryptocurrency into a
                stateful <code className="bg-black/40 px-1 py-0.5 rounded text-blue-300">Fiat_Escrow</code> vault
                the instant an order is opened. The buyer sends fiat directly via UPI or Bank Transfer. Once
                the seller verifies fiat deposit in their local bank account, the escrow engine automatically
                releases the locked crypto to the buyer's wallet.
              </p>
            </div>

            {/* Database Schemas */}
            <div>
              <h4 className="font-bold text-sm text-white mb-3">Database Schemas (SQLite 3)</h4>
              <div className="space-y-3 font-mono text-[11px]">
                <div className="bg-[#070A12] p-3 rounded-xl border border-white/5">
                  <span className="text-amber-400 font-bold block mb-1">TABLE: users</span>
                  <div className="text-gray-400">
                    id (TEXT PK), email, name, role (USER|MERCHANT), fiat_balance, btc_balance, eth_balance, usdt_balance
                  </div>
                </div>

                <div className="bg-[#070A12] p-3 rounded-xl border border-white/5">
                  <span className="text-purple-400 font-bold block mb-1">TABLE: merchants</span>
                  <div className="text-gray-400">
                    id (TEXT PK), user_id, trade_name, security_deposit, completion_rate, min_limit, max_limit, price_inr, supported_methods
                  </div>
                </div>

                <div className="bg-[#070A12] p-3 rounded-xl border border-white/5">
                  <span className="text-blue-400 font-bold block mb-1">TABLE: p2p_orders</span>
                  <div className="text-gray-400">
                    id (TEXT PK), order_no, buyer_id, seller_id, crypto_symbol, fiat_symbol, crypto_amount, fiat_amount, status
                  </div>
                </div>

                <div className="bg-[#070A12] p-3 rounded-xl border border-white/5">
                  <span className="text-emerald-400 font-bold block mb-1">TABLE: fiat_escrow</span>
                  <div className="text-gray-400">
                    id (TEXT PK), order_id, crypto_amount, crypto_symbol, status (LOCKED|RELEASED_TO_BUYER|DISPUTE)
                  </div>
                </div>
              </div>
            </div>

            {/* REST Endpoints */}
            <div>
              <h4 className="font-bold text-sm text-white mb-2">Backend REST API Endpoints</h4>
              <ul className="space-y-1.5 text-gray-300 font-mono text-[11px]">
                <li><span className="text-blue-400 font-bold">GET</span> /api/rates - Dynamic live currency pricing</li>
                <li><span className="text-blue-400 font-bold">GET</span> /api/merchants - Filtered P2P orderbook feed</li>
                <li><span className="text-emerald-400 font-bold">POST</span> /api/merchants/onboard - Register merchant ad</li>
                <li><span className="text-emerald-400 font-bold">POST</span> /api/orders/create - Lock crypto in escrow</li>
                <li><span className="text-emerald-400 font-bold">POST</span> /api/escrow/release - Atomically release crypto</li>
              </ul>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
        >
          Close Documentation
        </button>
      </div>
    </div>
  );
}

// ----------------------------------------------------
// Mount React Root
// ----------------------------------------------------
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
