# P2P Crypto & On-Ramp Platform Launcher
$ErrorActionPreference = "Stop"

$nodePath = "node"
try {
    $null = Get-Command node -ErrorAction Stop
} catch {
    $nodePath = "C:\Users\jagan\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "   CRYPTO-COINBRIDGE // FULL-STACK P2P & ESCROW PLATFORM" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "[*] Launching Browser at http://localhost:3001 ..." -ForegroundColor Yellow

Start-Process "http://localhost:3001"
& $nodePath "$PSScriptRoot\server.js"
