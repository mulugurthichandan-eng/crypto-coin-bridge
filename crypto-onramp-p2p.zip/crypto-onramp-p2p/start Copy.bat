@echo off
title CRYPTO-COINBRIDGE // P2P Trading Platform
cls
echo ========================================================
echo    CRYPTO-COINBRIDGE // FULL-STACK P2P & ESCROW PLATFORM
echo ========================================================
echo.

set NODE_EXE=node
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Users\jagan\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
        set "NODE_EXE=C:\Users\jagan\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
    )
)

echo [*] Launching browser at http://localhost:3001 ...
start http://localhost:3001

echo [*] Starting Backend Server (Node.js + SQLite)...
"%NODE_EXE%" server.js
pause
