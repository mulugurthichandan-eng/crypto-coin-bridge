/**
 * P2P Crypto & On-Ramp Platform - Full-Stack Server
 * Powered by Node.js native HTTP + native SQLite (node:sqlite)
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

let PORT = parseInt(process.env.PORT || '3001', 10);
const DB_FILE = path.join(__dirname, 'p2p_crypto.db');
const PUBLIC_DIR = path.join(__dirname, 'public');

// Initialize SQLite Database
const db = new DatabaseSync(DB_FILE);

// Setup Schema Tables: Users, Merchants, P2P_Orders, Fiat_Escrow
function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE,
      name TEXT,
      role TEXT DEFAULT 'USER',
      fiat_balance REAL DEFAULT 150000.0,
      btc_balance REAL DEFAULT 0.045,
      eth_balance REAL DEFAULT 1.25,
      usdt_balance REAL DEFAULT 2500.0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS merchants (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      trade_name TEXT,
      security_deposit REAL,
      deposit_asset TEXT DEFAULT 'USDT',
      completion_rate REAL DEFAULT 99.0,
      total_trades INTEGER DEFAULT 142,
      supported_methods TEXT,
      min_limit REAL DEFAULT 10000.0,
      max_limit REAL DEFAULT 100000.0,
      price_inr REAL DEFAULT 7710000.0,
      price_usd REAL DEFAULT 92500.0,
      crypto_symbol TEXT DEFAULT 'BTC',
      fiat_symbol TEXT DEFAULT 'INR',
      trade_type TEXT DEFAULT 'BUY',
      is_verified INTEGER DEFAULT 1,
      status TEXT DEFAULT 'ACTIVE',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS p2p_orders (
      id TEXT PRIMARY KEY,
      order_no TEXT UNIQUE,
      buyer_id TEXT,
      seller_id TEXT,
      merchant_id TEXT,
      crypto_symbol TEXT,
      fiat_symbol TEXT,
      crypto_amount REAL,
      fiat_amount REAL,
      unit_price REAL,
      payment_method TEXT,
      status TEXT DEFAULT 'PENDING',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS fiat_escrow (
      id TEXT PRIMARY KEY,
      order_id TEXT UNIQUE,
      crypto_amount REAL,
      crypto_symbol TEXT,
      locked_from_user_id TEXT,
      status TEXT DEFAULT 'LOCKED',
      lock_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      release_timestamp DATETIME,
      dispute_reason TEXT
    );
  `);

  // Seed default user if not exists
  const existingUser = db.prepare('SELECT id FROM users WHERE id = ?').get('usr_main');
  if (!existingUser) {
    db.prepare(`
      INSERT INTO users (id, email, name, role, fiat_balance, btc_balance, eth_balance, usdt_balance)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run('usr_main', 'trader@cryptocoinbridge.io', 'Alex Rivera', 'USER', 150000.0, 0.045, 1.25, 2500.0);
  }

  // Seed default merchants if empty
  const merchantCount = db.prepare('SELECT COUNT(*) as count FROM merchants').get().count;
  if (merchantCount === 0) {
    const seedMerchants = [
      {
        id: 'merch_1',
        user_id: 'usr_merch_1',
        trade_name: 'crypto_king',
        security_deposit: 1500,
        deposit_asset: 'USDT',
        completion_rate: 99.0,
        total_trades: 428,
        supported_methods: JSON.stringify(['UPI', 'Bank Transfer']),
        min_limit: 10000,
        max_limit: 100000,
        price_inr: 7710000,
        price_usd: 92480,
        crypto_symbol: 'BTC',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      },
      {
        id: 'merch_2',
        user_id: 'usr_merch_2',
        trade_name: 'trade_fast',
        security_deposit: 800,
        deposit_asset: 'USDT',
        completion_rate: 95.0,
        total_trades: 219,
        supported_methods: JSON.stringify(['UPI']),
        min_limit: 5000,
        max_limit: 50000,
        price_inr: 7708000,
        price_usd: 92450,
        crypto_symbol: 'BTC',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      },
      {
        id: 'merch_3',
        user_id: 'usr_merch_3',
        trade_name: 'apex_liquidity',
        security_deposit: 3000,
        deposit_asset: 'USDT',
        completion_rate: 98.4,
        total_trades: 612,
        supported_methods: JSON.stringify(['UPI', 'Bank Transfer', 'IMPS']),
        min_limit: 20000,
        max_limit: 250000,
        price_inr: 7712500,
        price_usd: 92510,
        crypto_symbol: 'BTC',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      },
      {
        id: 'merch_4',
        user_id: 'usr_merch_4',
        trade_name: 'delhi_crypto_trader',
        security_deposit: 500,
        deposit_asset: 'USDT',
        completion_rate: 97.2,
        total_trades: 185,
        supported_methods: JSON.stringify(['UPI', 'PhonePe', 'GPay']),
        min_limit: 1000,
        max_limit: 75000,
        price_inr: 7705586.3,
        price_usd: 92420,
        crypto_symbol: 'BTC',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      },
      {
        id: 'merch_5',
        user_id: 'usr_merch_5',
        trade_name: 'instant_cashout',
        security_deposit: 2000,
        deposit_asset: 'USDT',
        completion_rate: 99.5,
        total_trades: 890,
        supported_methods: JSON.stringify(['UPI', 'Bank Transfer']),
        min_limit: 5000,
        max_limit: 150000,
        price_inr: 7695000,
        price_usd: 92250,
        crypto_symbol: 'BTC',
        fiat_symbol: 'INR',
        trade_type: 'SELL',
        is_verified: 1
      },
      {
        id: 'merch_6',
        user_id: 'usr_merch_6',
        trade_name: 'usdt_express',
        security_deposit: 1000,
        deposit_asset: 'USDT',
        completion_rate: 99.1,
        total_trades: 1140,
        supported_methods: JSON.stringify(['UPI', 'Bank Transfer']),
        min_limit: 1000,
        max_limit: 100000,
        price_inr: 90.45,
        price_usd: 1.002,
        crypto_symbol: 'USDT',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      },
      {
        id: 'merch_7',
        user_id: 'usr_merch_7',
        trade_name: 'eth_prime_deals',
        security_deposit: 1200,
        deposit_asset: 'USDT',
        completion_rate: 96.8,
        total_trades: 330,
        supported_methods: JSON.stringify(['UPI', 'Bank Transfer']),
        min_limit: 5000,
        max_limit: 120000,
        price_inr: 284500,
        price_usd: 3415,
        crypto_symbol: 'ETH',
        fiat_symbol: 'INR',
        trade_type: 'BUY',
        is_verified: 1
      }
    ];

    const insertStmt = db.prepare(`
      INSERT INTO merchants (
        id, user_id, trade_name, security_deposit, deposit_asset,
        completion_rate, total_trades, supported_methods, min_limit,
        max_limit, price_inr, price_usd, crypto_symbol, fiat_symbol,
        trade_type, is_verified
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const m of seedMerchants) {
      insertStmt.run(
        m.id, m.user_id, m.trade_name, m.security_deposit, m.deposit_asset,
        m.completion_rate, m.total_trades, m.supported_methods, m.min_limit,
        m.max_limit, m.price_inr, m.price_usd, m.crypto_symbol, m.fiat_symbol,
        m.trade_type, m.is_verified
      );
    }
  }
}

initDatabase();

// Base exchange rates (Dynamic with small jitter simulation)
const BASE_RATES = {
  INR: {
    BTC: 7705586.30,
    ETH: 284320.50,
    USDT: 90.25,
    SOL: 16420.00
  },
  USD: {
    BTC: 92450.00,
    ETH: 3410.00,
    USDT: 1.00,
    SOL: 196.80
  },
  EUR: {
    BTC: 85200.00,
    ETH: 3140.00,
    USDT: 0.92,
    SOL: 181.20
  },
  AED: {
    BTC: 339500.00,
    ETH: 12520.00,
    USDT: 3.67,
    SOL: 722.50
  }
};

// Helper: parse JSON request body
function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

// Helper: send JSON response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(data));
}

// Request dispatcher
const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  const urlObj = new URL(req.url, `http://${req.headers.host}`);
  const pathname = urlObj.pathname;

  try {
    // ----------------------------------------------------
    // API: GET /api/rates
    // ----------------------------------------------------
    if (pathname === '/api/rates' && req.method === 'GET') {
      return sendJson(res, 200, {
        success: true,
        rates: BASE_RATES,
        timestamp: Date.now()
      });
    }

    // ----------------------------------------------------
    // API: GET /api/user/profile
    // ----------------------------------------------------
    if (pathname === '/api/user/profile' && req.method === 'GET') {
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get('usr_main');
      const recentOrders = db.prepare(`
        SELECT o.*, e.status as escrow_status
        FROM p2p_orders o
        LEFT JOIN fiat_escrow e ON o.id = e.order_id
        ORDER BY o.created_at DESC LIMIT 10
      `).all();

      return sendJson(res, 200, {
        success: true,
        user,
        recentOrders
      });
    }

    // ----------------------------------------------------
    // API: POST /api/auth/switch-role
    // ----------------------------------------------------
    if (pathname === '/api/auth/switch-role' && req.method === 'POST') {
      const body = await parseJsonBody(req);
      const newRole = body.role === 'MERCHANT' ? 'MERCHANT' : 'USER';
      db.prepare('UPDATE users SET role = ? WHERE id = ?').run(newRole, 'usr_main');
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get('usr_main');
      return sendJson(res, 200, { success: true, user });
    }

    // ----------------------------------------------------
    // API: GET /api/merchants
    // ----------------------------------------------------
    if (pathname === '/api/merchants' && req.method === 'GET') {
      const crypto = urlObj.searchParams.get('crypto') || 'BTC';
      const fiat = urlObj.searchParams.get('fiat') || 'INR';
      const type = (urlObj.searchParams.get('type') || 'BUY').toUpperCase();

      const merchants = db.prepare(`
        SELECT * FROM merchants
        WHERE crypto_symbol = ? AND fiat_symbol = ? AND trade_type = ? AND status = 'ACTIVE'
        ORDER BY completion_rate DESC, total_trades DESC
      `).all(crypto, fiat, type);

      const parsed = merchants.map(m => ({
        ...m,
        supported_methods: JSON.parse(m.supported_methods || '[]')
      }));

      return sendJson(res, 200, {
        success: true,
        crypto,
        fiat,
        trade_type: type,
        merchants: parsed
      });
    }

    // ----------------------------------------------------
    // API: POST /api/merchants/onboard
    // Screen 3: P2P Merchant Onboarding
    // ----------------------------------------------------
    if (pathname === '/api/merchants/onboard' && req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { tradeName, securityDeposit, supportedMethods, minLimit, maxLimit, cryptoSymbol, fiatSymbol, priceInr } = body;

      if (!tradeName) {
        return sendJson(res, 400, { success: false, error: 'Trade name is required.' });
      }

      const merchantId = 'merch_' + Date.now();
      const depositVal = parseFloat(securityDeposit) || 500;
      const methods = Array.isArray(supportedMethods) && supportedMethods.length > 0
        ? supportedMethods
        : ['UPI', 'Bank Transfer'];

      const minVal = parseFloat(minLimit) || 5000;
      const maxVal = parseFloat(maxLimit) || 100000;
      const crypto = cryptoSymbol || 'BTC';
      const fiat = fiatSymbol || 'INR';
      const price = parseFloat(priceInr) || (BASE_RATES[fiat] && BASE_RATES[fiat][crypto] ? BASE_RATES[fiat][crypto] * 1.002 : 7710000);

      db.prepare(`
        INSERT INTO merchants (
          id, user_id, trade_name, security_deposit, deposit_asset,
          completion_rate, total_trades, supported_methods, min_limit,
          max_limit, price_inr, crypto_symbol, fiat_symbol, trade_type, is_verified
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        merchantId, 'usr_main', tradeName.trim(), depositVal, 'USDT',
        100.0, 0, JSON.stringify(methods), minVal, maxVal, price,
        crypto, fiat, 'BUY', 1
      );

      // Upgrade user role to MERCHANT
      db.prepare("UPDATE users SET role = 'MERCHANT' WHERE id = ?").run('usr_main');

      return sendJson(res, 201, {
        success: true,
        message: 'Merchant registered successfully! Your buy/sell ad is now active on P2P Hub.',
        merchantId,
        tradeName
      });
    }

    // ----------------------------------------------------
    // API: POST /api/orders/create
    // Screen 2 & Screen 4: Create P2P order with Escrow lock
    // ----------------------------------------------------
    if (pathname === '/api/orders/create' && req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { merchantId, cryptoSymbol, fiatSymbol, fiatAmount, cryptoAmount, paymentMethod } = body;

      const orderId = 'ord_' + Math.floor(100000 + Math.random() * 900000);
      const orderNo = 'P2P-' + Math.floor(10000000 + Math.random() * 90000000);
      const fiat = fiatSymbol || 'INR';
      const crypto = cryptoSymbol || 'BTC';
      const fiatVal = parseFloat(fiatAmount) || 70000;
      const cryptoVal = parseFloat(cryptoAmount) || (fiatVal / (BASE_RATES[fiat][crypto] || 7705586.3));
      const unitPrice = fiatVal / cryptoVal;
      const pMethod = paymentMethod || 'Peer-to-Peer (P2P)';

      // 1. Insert order
      db.prepare(`
        INSERT INTO p2p_orders (
          id, order_no, buyer_id, seller_id, merchant_id,
          crypto_symbol, fiat_symbol, crypto_amount, fiat_amount,
          unit_price, payment_method, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        orderId, orderNo, 'usr_main', merchantId || 'merch_1', merchantId || 'merch_1',
        crypto, fiat, cryptoVal, fiatVal, unitPrice, pMethod, 'ESCROW_LOCKED'
      );

      // 2. Lock crypto in Escrow
      const escrowId = 'esc_' + Date.now();
      db.prepare(`
        INSERT INTO fiat_escrow (
          id, order_id, crypto_amount, crypto_symbol, locked_from_user_id, status
        ) VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        escrowId, orderId, cryptoVal, crypto, merchantId || 'merch_1', 'LOCKED'
      );

      return sendJson(res, 201, {
        success: true,
        order: {
          id: orderId,
          orderNo,
          cryptoSymbol: crypto,
          fiatSymbol: fiat,
          cryptoAmount: cryptoVal,
          fiatAmount: fiatVal,
          unitPrice,
          paymentMethod: pMethod,
          status: 'ESCROW_LOCKED',
          escrow: {
            id: escrowId,
            status: 'LOCKED',
            message: `Escrow Engine: ${cryptoVal.toFixed(8)} ${crypto} has been safely locked from seller's wallet into smart escrow.`
          }
        }
      });
    }

    // ----------------------------------------------------
    // API: POST /api/escrow/pay
    // Buyer marks fiat payment completed
    // ----------------------------------------------------
    if (pathname === '/api/escrow/pay' && req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { orderId } = body;

      db.prepare(`
        UPDATE p2p_orders
        SET status = 'PAID_MARKED', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(orderId);

      return sendJson(res, 200, {
        success: true,
        orderId,
        status: 'PAID_MARKED',
        message: 'Payment notification sent to Merchant. Awaiting merchant confirmation to release crypto.'
      });
    }

    // ----------------------------------------------------
    // API: POST /api/escrow/release
    // Merchant confirms payment & Escrow Engine releases crypto to buyer
    // ----------------------------------------------------
    if (pathname === '/api/escrow/release' && req.method === 'POST') {
      const body = await parseJsonBody(req);
      const { orderId } = body;

      const order = db.prepare('SELECT * FROM p2p_orders WHERE id = ?').get(orderId);
      if (!order) {
        return sendJson(res, 404, { success: false, error: 'Order not found.' });
      }

      // Update escrow record
      db.prepare(`
        UPDATE fiat_escrow
        SET status = 'RELEASED_TO_BUYER', release_timestamp = CURRENT_TIMESTAMP
        WHERE order_id = ?
      `).run(orderId);

      // Update order status
      db.prepare(`
        UPDATE p2p_orders
        SET status = 'COMPLETED', updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(orderId);

      // Credit buyer wallet
      const cryptoCol = `${order.crypto_symbol.toLowerCase()}_balance`;
      try {
        db.prepare(`
          UPDATE users
          SET ${cryptoCol} = ${cryptoCol} + ?
          WHERE id = ?
        `).run(order.crypto_amount, order.buyer_id);
      } catch (err) {
        console.warn('Wallet balance update warning:', err.message);
      }

      const updatedUser = db.prepare('SELECT * FROM users WHERE id = ?').get('usr_main');

      return sendJson(res, 200, {
        success: true,
        orderId,
        status: 'COMPLETED',
        message: `Escrow Released! ${order.crypto_amount.toFixed(8)} ${order.crypto_symbol} has been deposited to buyer wallet.`,
        user: updatedUser
      });
    }

    // ----------------------------------------------------
    // API: GET /api/db/schema
    // FSD Architecture inspection: returns database tables, row counts, DDL
    // ----------------------------------------------------
    if (pathname === '/api/db/schema' && req.method === 'GET') {
      const tables = ['users', 'merchants', 'p2p_orders', 'fiat_escrow'];
      const stats = {};
      for (const t of tables) {
        const count = db.prepare(`SELECT COUNT(*) as count FROM ${t}`).get().count;
        const sample = db.prepare(`SELECT * FROM ${t} LIMIT 3`).all();
        stats[t] = { count, sample };
      }

      return sendJson(res, 200, {
        success: true,
        architecture: 'FSD (Feature-Sliced Design) + Node 24 SQLite Embedded Engine',
        tables: stats,
        escrowStates: [
          'PENDING: Order placed, awaiting seller asset locking',
          'ESCROW_LOCKED: Crypto locked in protocol escrow vault',
          'PAID_MARKED: Buyer marked fiat transferred via UPI/Bank',
          'RELEASED_TO_BUYER: Merchant confirmed payment receipt -> Escrow transferred',
          'DISPUTE_HOLD: Arbitrator intervenes if payment is unverified within 15m'
        ]
      });
    }

    // ----------------------------------------------------
    // Static file serving: public/
    // ----------------------------------------------------
    let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

    // If file doesn't exist, fallback to index.html for SPA routing
    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      filePath = path.join(PUBLIC_DIR, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const mimeTypes = {
      '.html': 'text/html; charset=utf-8',
      '.css': 'text/css; charset=utf-8',
      '.js': 'application/javascript; charset=utf-8',
      '.jsx': 'text/javascript; charset=utf-8',
      '.json': 'application/json',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.svg': 'image/svg+xml',
      '.ico': 'image/x-icon'
    };

    const contentType = mimeTypes[ext] || 'text/plain';
    const content = fs.readFileSync(filePath);
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);

  } catch (error) {
    console.error('Server error:', error);
    sendJson(res, 500, { success: false, error: error.message });
  }
});

function startListening(port) {
  server.removeAllListeners('error');
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE' || err.code === 'EACCES') {
      console.warn(`Port ${port} not available (${err.code}), trying port ${port + 1}...`);
      startListening(port + 1);
    } else {
      console.error('Server listen error:', err);
    }
  });

  server.listen(port, '127.0.0.1', () => {
    console.log(`========================================================`);
    console.log(`🚀 CRYPTO-COINBRIDGE & P2P HUB SERVER READY`);
    console.log(`📡 URL: http://localhost:${port}`);
    console.log(`💾 SQLite DB: ${DB_FILE}`);
    console.log(`========================================================`);
  });
}

startListening(PORT);
